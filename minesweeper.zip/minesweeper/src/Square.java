import javax.swing.*;
import java.awt.*;

public class Square extends JButton {
    // Resource loader
    private ClassLoader loader = getClass().getClassLoader();

    // Square mine icon
    private Icon mine = new ImageIcon((loader.getResource("res/newMine.png")));

    // blank square
    private Icon blank = new ImageIcon(loader.getResource("res/revealed.png"));

    // Square back image
    private Icon back = new ImageIcon(loader.getResource("res/back.png"));

    // ID + Name
    private int id;
    private String customName;

    // Default constructor
    public Square() { super(); }

    // Constructor with square back initialization
    public Square(ImageIcon frontImage)
    {
        super();
        back = frontImage;
        super.setIcon(back);
        this.setSize(40, 40);
    }

    // Set the image used as the front of the square
    public void setImage(ImageIcon frontImage) { back = frontImage; }

    // Card flipping functions
    public void showMine() { super.setIcon(mine); }
    public void showBlank() { super.setIcon(blank);}
    public void hideFront() { super.setIcon(back); }

    // Metadata: ID number
    public int id() { return id; }
    public void setID(int i) { id = i; }

    // Metadata: Custom name
    public String customName() { return customName; }
    public void setCustomName(String s) { customName = s; }
}
